package controller.venta;

import java.awt.List;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import domain.session.session;
import domain.venta.Producto;
import service.venta.PedidoProductoService;
import service.venta.ProductoService;


@Controller
@SessionAttributes({ "user_inicio" })
public class ProductoController {

	@Autowired
	private ProductoService service;
	
	@Autowired
	private PedidoProductoService carrito;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, false));
	}

	@RequestMapping(value = "/catalogo", method = RequestMethod.GET)
	public String showProductCatalog(Model model) {
		if ((model.containsAttribute("user_inicio") == true)) {
			String uss=((session) model.asMap().get("user_inicio")).getId();
			model.addAttribute("cantidadCarrito",carrito.cantidadPedido(uss));
			model.addAttribute("productos", service.listarProductos());
			return "key/catalogo";
		}else{
			model.addAttribute("productos", service.listarProductos());
			return "key/catalogo";
		}
		
		
	}
	
	@RequestMapping(value = "/producto-detail", method = RequestMethod.GET)
	public String showDetailProductoPage(Model model,@RequestParam String id) {
		if ((model.containsAttribute("user_inicio") == true)) {
			String uss=((session) model.asMap().get("user_inicio")).getId();
			model.addAttribute("cantidadCarrito",carrito.cantidadPedido(uss));
			model.addAttribute("producto", service.consultarProducto(id));
			return "key/detalle-producto";
		}else{
			model.addAttribute("producto", service.consultarProducto(id));
			return "key/detalle-producto";
		}
		
	}
	
	@RequestMapping(value = "/admin/list-productos", method = RequestMethod.GET)
	public String showTodosList(Model model) {
		if ((model.containsAttribute("user_inicio") == true)&&(((session) model.asMap().get("user_inicio")).getRol() == 1)) {
			model.addAttribute("productos", service.listarProductos());
			return "key/lista-producto";
		}
		else{
			return"redirect:/index/login";
		}
		
	}
	

	@RequestMapping(value = "/admin/add-producto", method = RequestMethod.GET)
	public String showAddProductoPage(Model model) {
		if ((model.containsAttribute("user_inicio") == true)&&(((session) model.asMap().get("user_inicio")).getRol() == 1)) {
			model.addAttribute("producto", new Producto());
			return "key/agregar-producto";
		}else{
			return"redirect:/admin/login";
		}
		
		
	}
	
	
	@RequestMapping(value = "/admin/update-producto", method = RequestMethod.GET)
	public String showUpdateProductoPage(Model model,@RequestParam String id) {
		if ((model.containsAttribute("user_inicio") == true)&&(((session) model.asMap().get("user_inicio")).getRol() == 1)) {
			model.addAttribute("producto", service.consultarProducto(id));
			return "key/agregar-producto";
		}else{
			return"redirect:/admin/login";
		}
		
	}
	
	

	
	
	@RequestMapping(value = "/admin/add-update-producto", method = RequestMethod.POST)
	public @ResponseBody String addUpdateTodo(Model model, @RequestParam String id,@RequestParam String nombre
			,@RequestParam int precio,@RequestParam String descripcion) {
		
		System.out.println("entreeeee");
		if ((model.containsAttribute("user_inicio") == true)&&(((session) model.asMap().get("user_inicio")).getRol() == 1)) {
			if (service.existeProducto(id)){
				Producto producto=new Producto();
				producto.setDescripcion(descripcion);
				producto.setId_producto(id);
				producto.setNombre_producto(nombre);
				producto.setPrecio(precio);
				service.agregarProducto(true, producto);
				return "Done";
			}
			else {
				Producto producto=new Producto();
				producto.setDescripcion(descripcion);
				producto.setId_producto(id);
				producto.setNombre_producto(nombre);
				producto.setPrecio(precio);
				service.agregarProducto(false, producto);
				return "Done";
			}
			
		}else{
			return"sesion";
		}
		
	}

	@RequestMapping(value = "/admin/delete-producto", method = RequestMethod.POST)
	public @ResponseBody String deleteTodo(Model model,@RequestParam String id) {
		
		if ((model.containsAttribute("user_inicio") == true)&&(((session) model.asMap().get("user_inicio")).getRol() == 1)) {
			
			if(service.existeProducto(id)){
				System.out.println("entrooooooo    ------------");
				service.borrarProducto(id);
				
				java.util.List<Producto> results = service.listarProductos();// carrito.getListaProductos(uss);
				String res= "<table class='table table-hover'>"
						+"<thead> <tr>"
						+ "<th>Id</th>"
						+ "<th>Nombre</th>"
						+ "<th>Precio</th>"
						+ "<th>Descripcion</th>"
						+ "<th></th>"
						+ "</tr>"
						+ "</thead>"
						+ "<tbody>";
						for(Producto result:results){
							res= res+"<tr>"
							+ "<td>"+result.getId_producto()+"</td>"
							+ "<td>"+result.getNombre_producto()+"</td>"
							+ "<td>"+result.getPrecio()+"</td>"
							+ "<td>"+result.getDescripcion()+"</td>"
							+ "<td><a type='button' class='btn btn-primary'"
							+ "id='btnEditar' href='/admin/update-producto?id="+result.getId_producto()+"'>Editar</a> <a type='button'"
							+ "class='btn btn-warning' id='btnEliminar' onClick='ajaxDel("+result.getId_producto()+")'>Eliminar</a>"
							+ "</td>"
							+ "</tr>"
							+ "</tbody>";
						}
						res=res+"</table>";
				return res;
						
			}else{
				return "error";
				
			}
			
		}else{
			return"sesion";
		}
		
	}

}