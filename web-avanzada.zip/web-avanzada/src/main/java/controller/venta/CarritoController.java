package controller.venta;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import domain.session.session;
import domain.venta.Pedido;
import domain.venta.PedidoProducto;
import domain.venta.Producto;
import service.venta.PedidoProductoService;
import service.venta.PedidoService;
import service.venta.ProductoService;

@Controller
@SessionAttributes({ "user_inicio" })
public class CarritoController {
	
	@Autowired
	private PedidoProductoService carrito;
	
	@Autowired
	private ProductoService service;
	
	@Autowired
	private PedidoService pedidoService;
	
	@RequestMapping(value = "/list-carrito", method = RequestMethod.GET)
	public String showCarritoList(Model model) {
		if ((model.containsAttribute("user_inicio") == true)) {
			String uss=((session) model.asMap().get("user_inicio")).getId();
			//carrito.agregarProducto(false,3,service.consultarProducto("123"),((session) model.asMap().get("user_inicio")).getId());
			
			java.util.List<Object[]> results = carrito.getListaProductos(uss);
			model.addAttribute("cantidadCarrito",carrito.cantidadPedido(uss));
			model.addAttribute("productos",results);
			return "key/carrito";
		}
		else{
			return"redirect:/index/login";
		}
		
	}
	
	@RequestMapping(value = "/add-producto-carrito", method = RequestMethod.POST)
	public @ResponseBody String addProducto(Model model, @RequestParam("id_producto") String id,
			@RequestParam("cantidad") int cantidad ) {
		
		if ((model.containsAttribute("user_inicio") == true)) {
			if(service.existeProducto(id)){
				carrito.agregarProducto(false,cantidad,service.consultarProducto(id),((session) model.asMap().get("user_inicio")).getId());
				
				return "Done";
			}else{
				return "error";
				
			}
			
		}else{
			return"sesion";
		}
		
	}
	
	@RequestMapping(value = "/del-producto-carrito", method = RequestMethod.POST)
	public @ResponseBody String deleteProducto(Model model, @RequestParam("id_producto") String producto,
			@RequestParam("id_pedido") String pedido ) {
		
		if ((model.containsAttribute("user_inicio") == true)) {
			System.out.println(pedido);
			if(pedidoService.existePedido(pedido)){
				carrito.borrarProducto(producto,pedido);
				String uss=((session) model.asMap().get("user_inicio")).getId();
				//carrito.agregarProducto(false,3,service.consultarProducto("123"),((session) model.asMap().get("user_inicio")).getId());
				
				java.util.List<Object[]> results = carrito.getListaProductos(uss);
				String res= "<table class='table table-hover'>"
						+"<thead> <tr>"
						+ "<th>Nombre</th>"
						+ "<th>Descripcion</th>"
						+ "<th>Cantidad</th>"
						+ "<th>Precio</th>"
						+ "<th></th>"
						+ "</tr>"
						+ "</thead>"
						+ "<tbody>";
						for(Object[] result:results){
							res= res+"<tr>"
							+ "<td>"+result[0]+"</td>"
							+ "<td>"+result[1]+"</td>"
									+ "<td><input name='cantidad' value="+result[2]+" min='1' type='number'/></td>"
									+ "<td>"+result[3]+"</td>"
									+ "<td><a type='button' class='btn btn-primary'"
									+ "id='btnEditar' onClick='ajaxEdi("+result[4]+","+result[5]+")'>Editar</a> <a type='button'"
									+ "class='btn btn-warning' id='btnEliminar' onClick='ajaxDel("+result[4]+","+result[5]+")'>Eliminar</a>"
									+ "</td>"
									+ "</tr>"
									+ "</tbody>";
						}
						res=res+"</table>";
				return res;
						
			}else{
				return "error";
				
			}
			
		}else{
			return"sesion";
		}
		
	}
	
	/*@RequestMapping(value = "/delete-producto-carrito", method = RequestMethod.POST)
	public String deleteProducto(Model model, @RequestParam String id,
			@RequestParam int catidad ) {
		
		if ((model.containsAttribute("user_inicio") == true)) {
			if(service.existeProducto(producto.getId_producto())){
				//carrito.deleteProducto(service.consultarProducto(id));
				return "redirect:/list-productos";
			}else{
				return "redirect:/list-productos";
				
			}
			
		}else{
			return"redirect:/admin/login";
		}
		
	}*/
	
	/*@RequestMapping(value = "/update-producto-carrito", method = RequestMethod.POST)
	public String updateProducto(Model model, @RequestParam String id,
			@RequestParam int catidad ) {
		
		if ((model.containsAttribute("user_inicio") == true)) {
			if(service.existeProducto(producto.getId_producto())){
				//carrito.updateProducto(service.consultarProducto(id));
				return "redirect:/list-productos";
			}else{
				return "redirect:/list-productos";
				
			}
			
		}else{
			return"redirect:/admin/login";
		}
		
	}*/
	
}
