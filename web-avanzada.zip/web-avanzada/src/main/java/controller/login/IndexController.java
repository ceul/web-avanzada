package controller.login;

import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import domain.login.User;
import domain.session.session;
import service.login.UserManager;
/*
import domain.login.User;
import domain.session.session;
import service.login.UserManager;
*/
@Controller
@RequestMapping(value = "/index")
@SessionAttributes({ "user_inicio" })
public class IndexController {

	/** Logger for this class and subclasses */
	protected final Log logger = LogFactory.getLog(getClass());

	@Autowired
	private UserManager userManager;


		

	/*
	 * @Autowired private PermisoManager permisoManager;
	 */
	@RequestMapping(value = "/ingreso", method = RequestMethod.GET)
	public String employee(Map<String, Object> model) {
		model.put("user", new User());
		return "redirect:/catalogo";
		//return "key/adminLogin";
		//return "redirect:/list-productos";
	}
	
	@RequestMapping(value = "/admin/login", method = RequestMethod.GET)
	public String admin(Map<String, Object> model) {
		model.put("user", new User());
		return "key/adminLogin";
		//return "redirect:/list-productos";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String clienteLogin(Map<String, Object> model) {
		model.put("user", new User());
		return "key/adminLogin";
	}

	
	@RequestMapping(value = "/validar", method = RequestMethod.POST)
	 public String loginAdmin(@Valid @ModelAttribute("user") User user,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("user", new User());
			return "key/adminLogin";
		} else {
			User uss = userManager.val(user.getEmail(), user.getPass());
			if (uss != null) {
				model.addAttribute("user_inicio", new session(uss.getNombre(),uss.getRol(),uss.getEmail()
						,Integer.toString(uss.getId())));
				int rol=uss.getRol();
				if(rol==1){
					return "redirect:/admin/list-productos";
				}else{
					return "redirect:/catalogo";
				}
				
			} else {
				model.addAttribute("user", new User());
				return "key/errorLogin";
			}
		}
	}
	
	
	@RequestMapping(value = "/cliente/validar", method = RequestMethod.POST)
	 public String loginCliente(@Valid @ModelAttribute("user") User user,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("user", new User());
			return "key/index";
		} else {
			User uss = userManager.val(user.getEmail(), user.getPass());
			if (uss != null) {
				model.addAttribute("user_inicio", new session(uss.getNombre(),uss.getRol(),uss.getEmail()
						,Integer.toString(uss.getId())));
				return "redirect:/catalogo";
			} else {
				model.addAttribute("user", new User());
				return "key/index";
			}
		}
	}
	
	@RequestMapping(value = "/registrar", method = RequestMethod.GET)
	 public String registrarClienteGet(Map<String, Object> model) {
		model.put("user", new User());
		return "key/registro";
	}

	@RequestMapping(value = "/registrar", method = RequestMethod.POST)
	 public String registrarCliente(@Valid @ModelAttribute("user") User user,
			BindingResult result, Model model) {
		user.setRol(2);
		if(userManager.addUser(user)){
			return"redirect:/catalogo";
		}else{
			return"redirect:/registrar";
		}
	}
	
	@RequestMapping(value = "/salir", method = RequestMethod.GET)
	public String salir(Model model, SessionStatus status) {
		status.setComplete();
		model.addAttribute("user_inicio", new session() );
		return "redirect:/index/ingreso";
	}

	/*public void setuserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	public UserManager getUserManager() {
		return userManager;
	}*/

}
