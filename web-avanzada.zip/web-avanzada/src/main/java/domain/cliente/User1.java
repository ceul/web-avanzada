package domain.cliente;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;

@Entity
@Table(name = "cliente", schema = "cliente")
public class User1 {

	@Id
	@Column(name="id_cliente",unique=true,nullable=false)
	private int id;
	
	@Column(name="nombre_cliente",nullable=false)
	private String nombre;
	
	@Column(name="primer_apellido",nullable=false)
	private String apellido1;
	
	@Column(name="segundo_apellido")
	private String apellido2;
	
	@Column(name="email",nullable=false,unique=true)
	private String email;
	
	@Column(name="direccion", nullable=false)
	private String direccion;
	
	@Column(name="telefono",nullable=false)
	private String telefono;
	
	@Column(name="pass",nullable=false)
	private String password;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<UserRole> userRole = new HashSet<UserRole>(0);
	
	

	public User1() {
	}

	



	public int getId() {
		return this.id;
	}

	public void setUsername(int id) {
		this.id = id;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido1() {
		return apellido1;
	}



	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}



	public String getApellido2() {
		return apellido2;
	}



	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getDireccion() {
		return direccion;
	}



	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}



	public String getTelefono() {
		return telefono;
	}



	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}



	
	public Set<UserRole> getUserRole() {
		return this.userRole;
	}

	public void setUserRole(Set<UserRole> userRole) {
		this.userRole = userRole;
	}





	@Override
	public String toString() {
		return "User [id=" + id + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2
				+ ", email=" + email + ", direccion=" + direccion + ", telefono=" + telefono + ", password=" + password
				+ ", userRole=" + userRole + "]";
	}


	


	
	

}
