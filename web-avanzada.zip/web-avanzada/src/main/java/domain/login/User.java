package domain.login;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.util.DigestUtils;



@Entity
@Table(name="cliente", schema="cliente") 
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
	@Column(name="id_cliente",unique=true,nullable=false)
	private int id;
	
	@Column(name="nombre_cliente",nullable=false)
	private String nombre;
	
	@Column(name="primer_apellido",nullable=false)
	private String apellido1;
	
	@Column(name="segundo_apellido")
	private String apellido2;
	
	@Column(name="email",nullable=false,unique=true)
	private String email;
	
	@Column(name="direccion", nullable=false)
	private String direccion;
	
	@Column(name="telefono",nullable=false)
	private String telefono;
	
	@Column(name="pass",nullable=false)
	private String pass;
	
	@Column (name="rol",nullable=false)
	private int rol;
  

	public int getRol() {
		return rol;
	}

	public void setRol(int rol) {
		this.rol = rol;
	}

	public User() {
		// TODO Auto-generated constructor stub
	}
        
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    } 
    
    public String getPass() {
        return pass;
    }
    
    public void setPass(String pass) {
    	/*try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] messageDigest = md.digest(pass.getBytes());
			BigInteger number = new BigInteger(1, messageDigest);
			String hashtext = number.toString(16);
			while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
			this.pass = hashtext;
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  */
    	this.pass=pass;
    }
    
   
  
    public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2
				+ ", email=" + email + ", direccion=" + direccion + ", telefono=" + telefono + ", pass=" + pass
				+ ", rol=" + rol + "]";
	}

	


	
}