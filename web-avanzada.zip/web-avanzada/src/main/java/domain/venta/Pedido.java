package domain.venta;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name = "pedido", schema="cliente")
public class Pedido {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "auto_gen")
	@SequenceGenerator(name = "auto_gen", sequenceName = "cliente.pedido_id_pedido_seq")
	@Column(name="id_pedido")
	private int id_pedido;
	
	@NotNull
	@Column(name="fecha_pedido")
	private Date fecha_pedido;
	
	@NotNull
	@Column(name="fk_cliente")
	private int fk_cliente;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.producto", cascade=CascadeType.ALL)
	private Set<PedidoProducto> productos=new HashSet<PedidoProducto>();
	
	
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fecha_pedido == null) ? 0 : fecha_pedido.hashCode());
		result = prime * result + fk_cliente;
		result = prime * result + id_pedido;
		result = prime * result + ((productos == null) ? 0 : productos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		if (fecha_pedido == null) {
			if (other.fecha_pedido != null)
				return false;
		} else if (!fecha_pedido.equals(other.fecha_pedido))
			return false;
		if (fk_cliente != other.fk_cliente)
			return false;
		if (id_pedido != other.id_pedido)
			return false;
		if (productos == null) {
			if (other.productos != null)
				return false;
		} else if (!productos.equals(other.productos))
			return false;
		return true;
	}

	public Pedido() {
		// TODO Auto-generated constructor stub
	}

	public int getId_pedido() {
		return id_pedido;
	}

	public Date getFecha_pedido() {
		return fecha_pedido;
	}

	public void setFecha_pedido(Date fecha_pedido) {
		this.fecha_pedido = fecha_pedido;
	}

	public int getFk_cliente() {
		return fk_cliente;
	}
	
	
	

	public void setId_pedido(int id_pedido) {
		this.id_pedido = id_pedido;
	}

	public void setFk_cliente(int fk_cliente) {
		this.fk_cliente = fk_cliente;
	}

	public Set<PedidoProducto> getProductos() {
		return productos;
	}

	public void setProductos(Set<PedidoProducto> productos) {
		this.productos = productos;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Pedido [id_pedido=" + id_pedido + ", fecha_pedido=" + fecha_pedido + ", fk_cliente=" + fk_cliente + "]";
	}
	
	
}
