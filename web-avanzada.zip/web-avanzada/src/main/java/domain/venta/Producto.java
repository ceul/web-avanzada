package domain.venta;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="producto", schema="cliente")
public class Producto {
	
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name="id_producto",updatable = false, nullable= false)
	private String id_producto;
	
	@NotEmpty
	@Column(name="nombre_producto")
	private String nombre_producto;
	
	@NotEmpty
	@Column(name="descripcion")
	private String descripcion;
	
	@NotNull
	@Column(name="precio")
	private int precio;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.pedido")
	private Set<PedidoProducto> pedidos=new HashSet<PedidoProducto>();
	
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Producto(String id_producto, String nombre_producto, String descripcion, int precio,
			Set<PedidoProducto> pedidos) {
		super();
		this.id_producto = id_producto;
		this.nombre_producto = nombre_producto;
		this.descripcion = descripcion;
		this.precio = precio;
		this.pedidos = pedidos;
	}


	@Override
	public String toString() {
		return "Producto [id_producto=" + id_producto + ", nombre_producto=" + nombre_producto + ", descripcion="
				+ descripcion + ", precio=" + precio + "]";
	}
	
	
	public Set<PedidoProducto> getPedidos() {
		return pedidos;
	}


	public void setPedidos(Set<PedidoProducto> pedidos) {
		this.pedidos = pedidos;
	}

	public String getId_producto() {
		return id_producto;
	}
	public void setId_producto(String id_producto) {
		this.id_producto = id_producto;
	}
	public String getNombre_producto() {
		return nombre_producto;
	}
	public void setNombre_producto(String nombre_producto) {
		this.nombre_producto = nombre_producto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

}
