package repository.venta;

import java.util.List;
import java.util.Map;

import domain.venta.Producto;;

public interface ProductoDao {

	public List<Producto> getProductoList();
    public boolean addProducto(Producto producto);
    public void deleteProducto(String id);
    public Producto getProducto(String id);
    public boolean editProducto(Producto producto);
    public boolean existeProducto(String id);
}
