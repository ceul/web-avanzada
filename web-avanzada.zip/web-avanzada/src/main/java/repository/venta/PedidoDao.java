package repository.venta;

import domain.venta.Pedido;

public interface PedidoDao {
	public long addPedido(Pedido pedido);
	public Pedido getPedido(String id);
	public boolean existePedido(String id);
}
