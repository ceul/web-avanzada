package repository.venta;

import java.util.List;

import domain.venta.Pedido;
import domain.venta.PedidoProducto;

public interface PedidoProductoDao {

	public List<PedidoProducto> getProductoList(String id);
    public boolean addPedidoProducto(PedidoProducto producto);
    public void deleteProducto(String id_producto,String id_pedido);
    public boolean editProducto(PedidoProducto producto);
    public Long getCantidad(String id);
    public List<Object[]> getProductosListar(String id);
    
}
