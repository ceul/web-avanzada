package repository.venta.Impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import domain.venta.Producto;
import repository.venta.ProductoDao;;

@Repository
public class ProductoDaoImpl implements ProductoDao{

	private EntityManager em = null;

	/*
	 * Sets the entity manager.
	 */
	@PersistenceContext
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")
	public List<Producto> getProductoList() {
		return em.createQuery("select p from Producto p").getResultList();
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addProducto(Producto producto) {
		if (em.find(Producto.class, producto.getId_producto()) == null) {
			em.persist(producto);
			return true;
		} else {
			return false;
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteProducto(String id) {
		Producto producto = em.find(Producto.class, id);
		if (producto != null) {
			em.remove(producto);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean existeProducto(String id) {
		Producto producto = em.find(Producto.class, id);
		if (producto != null) {
			return true;
		}
		else{
			return false;
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Producto getProducto(String id) {
		return (Producto) (em.find(Producto.class, id));
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public boolean editProducto(Producto producto) {
		try {
			em.merge(producto);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
}
