package repository.venta.Impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import domain.venta.Pedido;
import domain.venta.PedidoProducto;
import domain.venta.Producto;
import repository.venta.PedidoDao;

@Repository
public class PedidoDaoImpl implements PedidoDao{

	private EntityManager em = null;

	/*
	 * Sets the entity manager.
	 */
	@PersistenceContext
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")
	public List<Pedido> getProductoList() {
		return em.createQuery("select p from Pedido p").getResultList();
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public long addPedido(Pedido pedido) {
			Pedido id_pedido=em.merge(pedido);
			//em.getTransaction().commit();
			//int id=(int) em.createQuery("INSERT INTO Pedido p RETURNING p.id_pedido").getSingleResult();
			System.out.println(id_pedido.getId_pedido());
			return Long.valueOf(id_pedido.getId_pedido()).longValue();
		
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deletePedido(String id) {
		Pedido pedido = em.find(Pedido.class, id);
		if (pedido != null) {
			em.remove(pedido);
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Pedido getPedido(String id) {
		System.out.println("pasoooooo al get");
		Pedido pedido=(em.find(Pedido.class, Integer.parseInt(id)));
		System.out.println("paso el find");
		return pedido ;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Pedido> getClientePedido(String id) {
		Query query= (Query) em.createQuery("select p from Pedido p where p.fk_cliente=id");
		
		query.setParameter("id",id);
		
		return query.list();
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean existePedido(String id) {
		System.out.println("entroo al dao");
		Pedido pedido = em.find(Pedido.class,Integer.parseInt(id));
		if (pedido != null) {
			return true;
		}
		else{
			return false;
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public boolean editPedido(Pedido pedido) {
		try {
			em.merge(pedido);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
}
