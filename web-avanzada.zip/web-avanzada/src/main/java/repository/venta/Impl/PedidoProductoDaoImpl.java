package repository.venta.Impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import domain.venta.Pedido;
import domain.venta.PedidoProducto;
import domain.venta.PedidoProductoId;
import domain.venta.Producto;
import repository.venta.PedidoProductoDao;

@Repository
public class PedidoProductoDaoImpl implements PedidoProductoDao {

	private EntityManager em = null;

	/*
	 * Sets the entity manager.
	 */
	@PersistenceContext
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")
	public List<PedidoProducto> getProductoList(String id) {
		Query query= (Query) em.createQuery("select p from PedidoProducto p where p.pk.pedido="
				+ "(select k from Pedido k where k.fk_cliente= id) ");
		
		query.setParameter("id",id);
		
		return query.list();
	}
	
	@Transactional(readOnly = true)
	public Long getCantidad(String id) {
		Long query= (Long)em.createQuery("SELECT COUNT(p) FROM PedidoProducto p,Pedido pe "
				+" WHERE pe.fk_cliente="+id+" AND p.pk.pedido= pe.id_pedido").getSingleResult();
		
		return query;
	}
	
	@Transactional(readOnly = true)
	public List<Object[]> getProductosListar(String id) {
		List<Object[]> query= em.createQuery("SELECT p.nombre_producto,p.descripcion, pepr.cantidad,"
				+ "pepr.precio, pe.id_pedido,p.id_producto FROM "
				+ "PedidoProducto pepr,Producto p,Pedido pe WHERE pe.fk_cliente="+id+" AND "
						+ "pepr.pk.pedido= pe.id_pedido AND p.id_producto=pepr.pk.producto   ").getResultList();
		
		return query;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addPedidoProducto(PedidoProducto pedidoproducto) {
		
		//if (em.find(PedidoProductoDaoImpl.class, pedidoproducto.getPk()) == null) {
			System.out.println("entroooo-");
			em.persist(pedidoproducto);
			//em.getTransaction().commit();
			System.out.println("pasoooooo");
		   // em.close();
			return true;
		//} else {
			//return false;
	//	}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteProducto(String id_producto,String id_pedido) {
		Producto producto = em.find(Producto.class, id_producto);
		Pedido pedido = em.find(Pedido.class, Integer.parseInt(id_pedido));
		PedidoProductoId pk= new PedidoProductoId();
		pk.setPedido(pedido);
		pk.setProducto(producto);
		PedidoProducto pedidoProducto= em.find(PedidoProducto.class, pk);
		
		if (pedidoProducto != null) {
			em.remove(pedidoProducto);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean editProducto(PedidoProducto producto) {
		try {
			em.merge(producto);
			return true;
		} catch (Exception ex) {
			return false;
		}
	}
}
