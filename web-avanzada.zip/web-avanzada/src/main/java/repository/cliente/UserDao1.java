package repository.cliente;

import domain.cliente.User1;

public interface UserDao1 {

	User1 findByUserName(String username);

}