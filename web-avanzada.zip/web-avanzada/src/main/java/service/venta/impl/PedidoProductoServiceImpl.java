package service.venta.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import domain.venta.Pedido;
import domain.venta.PedidoProducto;
import domain.venta.Producto;
import repository.venta.PedidoDao;
import repository.venta.PedidoProductoDao;
import service.venta.PedidoProductoService;
import service.venta.ProductoService;

@Service
public class PedidoProductoServiceImpl implements PedidoProductoService {

	@Autowired
	private PedidoProductoDao carrito;
	
	@Autowired
	private PedidoDao pedido;
	

	public void agregarProducto(boolean existe, int cantidad, Producto producto, String id_cliente) {
		/*if (existe == true){
			pedidoDao.editProducto(producto);
		}
		else {*/
			Pedido pedido1= new Pedido();
			pedido1.setFecha_pedido(new Date());
			pedido1.setFk_cliente(Integer.parseInt(id_cliente));
			int id_pedido=(int) pedido.addPedido(pedido1);
			System.out.println("pasoooooo");
			//Pedido pedido2=pedido.getPedido(id_pedido);
			pedido1.setId_pedido(id_pedido);
			PedidoProducto carrito1=new PedidoProducto();
			carrito1.setPedido(pedido1);
			carrito1.setProducto(producto);
			carrito1.setCantidad(cantidad);
			carrito1.setPrecio(producto.getPrecio());
			pedido1.getProductos().add(carrito1);
			//System.out.println("pedido: "+carrito1.getPk().getPedido());
			carrito.addPedidoProducto(carrito1);
		//}
	}

	public void borrarProducto(String id_producto,String id_pedido) {
		carrito.deleteProducto(id_producto, id_pedido);;
	}
	
	
	public List<PedidoProducto> listarPedidosProductos(String id) {		
		return carrito.getProductoList(id);
	}
	
	
	public Long cantidadPedido(String id){
		return carrito.getCantidad(id);
	}
	public List<Object[]> getListaProductos(String id){
		return carrito.getProductosListar(id);
	}
}
