package service.venta.impl;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import domain.venta.Producto;
import repository.venta.ProductoDao;
import service.venta.ProductoService;

@Service
public class ProductoServiceImpl implements ProductoService{

	@Autowired
	private ProductoDao productoDao;
	
	
	public void agregarProducto(boolean existe, Producto producto) {
		if (existe == true){
			productoDao.editProducto(producto);
		}
		else {
			productoDao.addProducto(producto);
		}
	}

	public void borrarProducto(String id) {
		productoDao.deleteProducto(id);
	}
	
	
	public List<Producto> listarProductos() {		
		return productoDao.getProductoList();
	}
	
	public Producto consultarProducto(String id){
		return productoDao.getProducto(id);
	}
	
	public boolean existeProducto(String id){
		return productoDao.existeProducto(id);
	}
	
	
}
