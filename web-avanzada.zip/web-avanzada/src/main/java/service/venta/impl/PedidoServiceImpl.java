package service.venta.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import domain.venta.Pedido;
import domain.venta.Producto;
import repository.venta.PedidoDao;
import service.venta.PedidoService;

@Service
public class PedidoServiceImpl implements PedidoService {
	
	@Autowired
	private PedidoDao pedidoDao;
	
	public void agregarPedido(Pedido pedido) {
		
			pedidoDao.addPedido(pedido);
		
	}
	public void obtenerPedido (String id){
		pedidoDao.getPedido(id);
	}

	public boolean existePedido(String id){
		System.out.println("entroo al servicio");
		System.out.println(id);
		return pedidoDao.existePedido(id);
	}
}
