package service.venta;

import domain.venta.Pedido;

public interface PedidoService {
	public void agregarPedido(Pedido pedido);
	public void obtenerPedido (String id);
	public boolean existePedido(String id);
}
