package service.venta;

import java.util.List;

import domain.venta.Producto;

public interface ProductoService {

	public void agregarProducto (boolean existe, Producto producto);
	public void borrarProducto (String id);
	public List<Producto> listarProductos();
	public Producto consultarProducto(String id);
	public boolean existeProducto(String id);
	
}
