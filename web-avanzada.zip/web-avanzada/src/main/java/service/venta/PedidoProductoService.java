package service.venta;

import java.util.List;

import domain.venta.PedidoProducto;
import domain.venta.Producto;

public interface PedidoProductoService {
	public void agregarProducto(boolean existe, int cantidad, Producto producto, String id_cliente);
	public void borrarProducto(String id_producto,String id_pedido);
	public List<PedidoProducto> listarPedidosProductos(String id) ;
	public Long cantidadPedido(String id);
	public List<Object[]> getListaProductos(String id);
}
